const User = require('../models/user');
const Event = require('../models/events');

// Middleware to check if the user is a guest (not logged in)
exports.isGuest = (req, res, next) => {
    if (!req.session.userId) {
        return next();
    }
    return res.redirect('/profile');
};

// Middleware to check if the user is logged in
exports.isLoggedIn = (req, res, next) => {
    if (req.session.userId) {
        return next();
    } else {
        req.flash('error', 'Please log in to view your profile.');
        return res.redirect('/login');
    }
};

// Middleware to check if the user is the host of an event
exports.isHost = async (req, res, next) => {
    try {
        const event = await Event.findById(req.params.id).populate('user');
        if (event && event.user._id.equals(req.session.userId)) {
            return next();
        } else {
            req.flash('error', 'Unauthorized: You are not the host of this event.');
            res.redirect('/events/' + req.params.id);
        }
    } catch (error) {
        console.error(error);
        req.flash('error', 'Server error.');
        res.redirect('/events');
    }
};
