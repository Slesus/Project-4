const express = require('express');
const router = express.Router();
const mainCtrl = require('../controllers/daController');

// Main routes
router.get('/', mainCtrl.getHomePage);      // Route for the Home page
router.get('/about', mainCtrl.getAboutPage); // Route for the About page
router.get('/contact', mainCtrl.getContactPage); // Route for the Contact page

// Authentication routes
router.get('/login', mainCtrl.getLoginPage);    // Route for the Login page
router.get('/signup', mainCtrl.getSignupPage);  // Route for the Signup page

module.exports = router;