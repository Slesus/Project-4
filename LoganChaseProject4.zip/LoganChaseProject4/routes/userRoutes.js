const express = require('express');
const router = express.Router();
const userController = require('../controllers/userController');
const auth = require('../middleware/auth');

// Routes accessible only to guests
router.get('/signup', auth.isGuest, userController.viewRegistration);
router.post('/signup', auth.isGuest, userController.registerUser);
router.get('/login', auth.isGuest, userController.viewLogin);
router.post('/login', auth.isGuest, userController.loginUser);

// Routes accessible only to logged-in users
router.get('/profile', auth.isLoggedIn, userController.viewProfile);
router.get('/logout', auth.isLoggedIn, userController.logoutUser);

// Route to edit the user's profile
//router.get('/editProfile', auth.isLoggedIn, userController.editProfile);
//router.put('/profile', auth.isLoggedIn, userController.updateProfile);

module.exports = router;