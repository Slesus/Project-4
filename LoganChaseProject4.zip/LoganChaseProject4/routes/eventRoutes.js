const express = require('express');
const eventCtrl = require('../controllers/ctrlEvent');
const auth = require('../middleware/auth');

const router = express.Router();

// Publicly accessible routes
router.get('/', eventCtrl.index);

// Routes accessible only to logged-in users
router.get('/new', auth.isLoggedIn, eventCtrl.new);
router.post('/', auth.isLoggedIn, eventCtrl.create);

// Routes accessible only to the host of the event
router.get('/:id/edit', auth.isHost, eventCtrl.edit);
router.put('/:id', auth.isHost, eventCtrl.update);
router.delete('/:id', auth.isHost, eventCtrl.delete);

// Get details of a specific event by its ID
router.get('/:id', eventCtrl.show); 

module.exports = router;