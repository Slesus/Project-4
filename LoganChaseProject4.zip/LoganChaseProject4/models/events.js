const mongoose = require('mongoose');
const { Schema } = mongoose;

// Define the schema for the event data
const eventSchema = new Schema({
  title: { type: String, required: true },
  category: { 
    type: String, 
    required: true, 
    enum: ['Web Development', 'Cybersecurity']
  },
  hostName: { type: String, required: true },
  startDate: { type: Date, required: true },
  endDate: { type: Date, required: true },
  location: { type: String, required: true },
  details: { type: String, required: true },
  image: { type: String, required: true },
  user: {
    type: Schema.Types.ObjectId,
    ref: 'User',
    required: true
  }
});

// Create a mongoose model using the above schema
const Event = mongoose.model('Event', eventSchema);

// Export the model to be used in other parts of the application
module.exports = Event;