const path = require('path');

// Define daController to manage page rendering for different routes

// Function to render the home page
module.exports.getHomePage = (request, response) => {
    response.render('index'); // Use the 'index' view
};

// Function to render the about page
module.exports.getAboutPage = (request, response) => {
    response.render('about'); // Use the 'about' view
};

// Function to render the contact page
module.exports.getContactPage = (request, response) => {
    response.render('contact'); // Use the 'contact' view
};

// Function to render the login page
module.exports.getLoginPage = (request, response) => {
    response.render('login'); // Use the 'login' view
};

// Function to render the signup page
module.exports.getSignupPage = (request, response) => {
    response.render('signup'); // Use the 'signup' view
};