const bcrypt = require('bcrypt');
const User = require('../models/user');
const Event = require('../models/events');

const userController = {
  viewRegistration: function(req, res) {
    res.render('user/new');
  },

  registerUser: async function(req, res) {
    try {
      const existingUser = await User.findOne({ email: req.body.email });
      if (existingUser) {
        req.flash('error', 'Email already exists. Please log in or use another email.');
        return res.redirect('/signup');
      }

      const user = new User({
        firstName: req.body.firstName,
        lastName: req.body.lastName,
        email: req.body.email,
        password: req.body.password
      });

      await user.save();
      req.flash('success', 'Registration successful. Please log in.');
      res.redirect('/login');
    } catch (err) {
      console.error(err);
      req.flash('error', 'Unexpected error occurred during registration.');
      res.redirect('/signup');
    }
  },

  viewLogin: function(req, res) {
    res.render('user/login');
  },

  loginUser: async function(req, res) {
    try {
      const user = await User.findOne({ email: req.body.email });
      if (user && await bcrypt.compare(req.body.password, user.password)) {
        req.session.userId = user._id;
        req.session.firstName = user.firstName;
        req.flash('success', 'You are now logged in.');
        res.redirect('/profile');
      } else {
        req.flash('error', 'Invalid email or password.');
        res.redirect('/login');
      }
    } catch (err) {
      console.error(err);
      req.flash('error', 'An error occurred during login.');
      res.redirect('/login');
    }
  },

  viewProfile: async function(req, res) {
    try {
      const userId = req.session.userId;
      if (!userId) {
        req.flash('error', 'Please log in to view this page.');
        return res.redirect('/login');
      }
      const userWithEvents = await User.findById(userId).populate('events').exec();
      console.log('User with events:', userWithEvents); // Add this line for debugging
      res.render('user/profile', { user: userWithEvents });
    } catch (err) {
      console.error(err);
      req.flash('error', 'An error occurred while fetching user data.');
      res.redirect('/login');
    }
  }, 

  logoutUser: function(req, res) {
    // Set the flash message for successful logout before destroying the session
    req.flash('success', 'You have successfully logged out.');

    req.session.destroy(err => {
      if (err) {
        console.error(err);
        req.flash('error', 'Error during logout.');
      }

      // Clear the cookie after the session is destroyed
      res.clearCookie('connect.sid');

      // Redirect to login page after logging out
      res.redirect('/login');
    });
  }
};

module.exports = userController;