const Event = require('../models/events');
const User = require('../models/user');
const mongoose = require('mongoose');
const { DateTime } = require('luxon');


// Fetch all events and their categories for listing
module.exports.index = async (request, response, nextFunction) => {
    try {
        let allEvents = await Event.find().lean();
        let allCategories = await Event.distinct("category");

        // Include user data if logged in
        const userData = request.session.userId ? await User.findById(request.session.userId).lean() : null;

        response.render('events/index', {
            events: allEvents, 
            categories: allCategories,
            user: userData // Pass the user data for conditional rendering in EJS
        });
    } catch (err) {
        nextFunction(err);
    }
};


// Serve the form for creating a new event
module.exports.new = (request, response) => {
    response.render('events/new');
};

// Process the update for an existing event
module.exports.update = async (request, response, nextFunction) => {
    let id = request.params.id;

    // Validate the event ID before proceeding
    if (!mongoose.Types.ObjectId.isValid(id)) {
        return response.status(400).send("Invalid ObjectId.");
    }

    try {
        // Update event and validate input
        let event = await Event.findByIdAndUpdate(id, request.body, { new: true, runValidators: true }).lean();
        if (event) {
            response.redirect(`/events/${id}`);
        } else {
            throw new Error(`Event not found with id: ${id}`);
        }
    } catch (err) {
        // Handle validation errors or other errors
        if (err.name === "ValidationError") {
            response.status(400).send(err.message);
        } else {
            nextFunction(err);
        }
    }
};

// Remove an event from the database
module.exports.delete = async (request, response, nextFunction) => {
    let id = request.params.id;

    // Check if the provided ID is valid
    if (!mongoose.Types.ObjectId.isValid(id)) {
        return response.status(400).send("Invalid ObjectId.");
    }

    try {
        let event = await Event.findByIdAndRemove(id).lean();
        if (event) {
            response.redirect('/events');
        } else {
            throw new Error(`Event not found with id: ${id}`);
        }
    } catch (err) {
        nextFunction(err);
    }
};

// Display details of a specific event
module.exports.show = async (request, response, nextFunction) => {
    let id = request.params.id;
    
    try {
        let event = await Event.findById(id).populate('user').lean();
        let user = null;
        if (request.session.userId) {
            user = await User.findById(request.session.userId).lean(); // Add .lean() for consistency
        }
        response.render('events/show', { event, user: user });
    } catch (err) {
        nextFunction(err);
    }
};

// Serve the edit form for an existing event
module.exports.edit = async (request, response, nextFunction) => {
    let id = request.params.id;

    // Ensure the ID is in a valid format
    if (!mongoose.Types.ObjectId.isValid(id)) {
        return response.status(400).send("Invalid ObjectId.");
    }

    try {
        let event = await Event.findById(id).lean();
        if (event) {
            response.render('events/edit', { event });
        } else {
            throw new Error(`Event not found with id: ${id}`);
        }
    } catch (err) {
        nextFunction(err);
    }
};

module.exports.create = async (request, response, nextFunction) => {
    let userId = request.session.userId;

    if (!userId) {
        return response.status(403).send('You must be logged in to create an event.');
    }

    let event = new Event({
        ...request.body,
        user: userId // Set the user ID to the event
    });

    try {
        // Save the new event
        let savedEvent = await event.save();

        // Now find the user and update their events array
        let user = await User.findById(userId);
        user.events.push(savedEvent._id); // Push the new event's ID to the user's events array
        await user.save(); // Save the user document

        response.redirect('/events');
    } catch (err) {
        if (err.name === "ValidationError") {
            response.status(400).send(err.message);
        } else {
            nextFunction(err);
        }
    }
};