const express = require('express');
const morgan = require('morgan');
const methodOverride = require('method-override');
const mongoose = require('mongoose');
const session = require('express-session');
const MongoStore = require('connect-mongo');
const path = require('path');
const flash = require('connect-flash');
require('dotenv').config();

// MongoDB configuration
const mongoUri = process.env.MONGO_URI;

// Connect to MongoDB
mongoose.connect(mongoUri, { useNewUrlParser: true, useUnifiedTopology: true })
  .then(() => console.log('Connected to MongoDB'))
  .catch((error) => console.error('Failed to connect to MongoDB', error));

// Load route modules
const eventRoutes = require('./routes/eventRoutes');
const userRoutes = require('./routes/userRoutes');
const mainRoutes = require('./routes/mainRoutes');

// Initialize Express server
const app = express();

// Server configuration
const serverPort = process.env.SERVER_PORT || 8080;
const serverHost = process.env.SERVER_HOST || 'localhost';

// Set the view engine to EJS
app.set('view engine', 'ejs');

// Session configuration
app.use(session({
  secret: process.env.SESSION_SECRET || '234g3h423h4g2jk3h4g241ffs6',
  resave: false,
  saveUninitialized: true,
  store: MongoStore.create({ mongoUrl: mongoUri }),
  cookie: { secure: false }
}));

// Initialize flash messages
app.use(flash());

// Middleware to make flash messages available in all views
app.use((req, res, next) => {
  res.locals.success_msg = req.flash('success');
  res.locals.error_msg = req.flash('error');
  res.locals.messages = req.flash();
  next();
});

// Middleware to make user ID and name available in all views
app.use((req, res, next) => {
  if (req.session.userId) {
    res.locals.userId = req.session.userId;
    res.locals.firstName = req.session.firstName; // or whatever the property name is
  }
  next();
});

// Middleware setup
app.use(express.static(path.join(__dirname, 'public')));
app.use(express.urlencoded({ extended: true }));
app.use(morgan('tiny'));
app.use(methodOverride('_method'));

// Endpoint routes
app.use('/events', eventRoutes);
app.use('/', userRoutes);
app.use('/', mainRoutes);

// 404 error handler
app.use((req, res, next) => {
  const err = new Error(`The server cannot locate ${req.originalUrl}`);
  err.status = 404;
  next(err);
});

// General error handler
app.use((err, req, res, next) => {
  console.error(err.stack);
  err.status = err.status || 500;
  err.message = err.message || "Internal Server Error";
  res.status(err.status);
  res.render('error', { error: err });
});

// Start the server
app.listen(serverPort, serverHost, () => {
  console.log(`Server is running on ${serverHost}:${serverPort}`);
});

module.exports = app;